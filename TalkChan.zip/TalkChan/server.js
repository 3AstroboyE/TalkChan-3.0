const express = require('express');
const bodyParser = require('body-parser');
const nodemailer = require('nodemailer');
const fetch = require('node-fetch');

const app = express();
const PORT = 3000;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Configura el transporte de Nodemailer
const transporter = nodemailer.createTransport({
    service: 'Gmail',
    auth: {
        user: 'tuemail@gmail.com',
        pass: 'tucontraseña'
    }
});

// Ruta para manejar el formulario de registro
app.post('/register', async (req, res) => {
    const { name, email, password, phone, username, 'g-recaptcha-response': captcha } = req.body;

    if (!captcha) {
        return res.json({ success: false, message: 'Por favor complete el CAPTCHA' });
    }

    const secretKey = 'TU_CLAVE_DEL_SECRETKEY';
    const verifyUrl = `https://www.google.com/recaptcha/api/siteverify?secret=${secretKey}&response=${captcha}`;

    const response = await fetch(verifyUrl, { method: 'POST' });
    const captchaResult = await response.json();

    if (!captchaResult.success) {
        return res.json({ success: false, message: 'Falló la verificación del CAPTCHA' });
    }

    const mailOptions = {
        from: 'tuemail@gmail.com',
        to: email,
        subject: 'Confirma tu registro',
        text: `Hola ${name}, por favor confirma tu registro haciendo clic en el siguiente enlace: http://localhost:3000/confirm?email=${email}`
    };

    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            return res.status(500).send(error.toString());
        }
        res.send('Correo de confirmación enviado');
    });
});

// Ruta para confirmar el registro
app.get('/confirm', (req, res) => {
    const { email } = req.query;
    // Aquí puedes actualizar la base de datos para marcar el correo como confirmado
    res.redirect('http://127.0.0.1:5500/index.html');
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
